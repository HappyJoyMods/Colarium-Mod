using Terraria.ModLoader;

namespace ColariumMod
{
	class ColariumMod : Mod
	{
		public ColariumMod()
		{
		}
	}
}
